package app.etl.instrument.b1

import app.etl.instrument.RawInstrument
import app.etl.instrument.b1.EquityIndexSwap20Instrument.{RawEquityIndexSwap, RdmEquityIndexSwap}
import org.scalatest.FunSuite

class EquityIndexSwap20InstrumentTest extends FunSuite {

  test("testMapToRdm") {
    val raw20: RawInstrument = RawEquityIndexSwap(
      contractId = "13",
      negoId = "413",
      ethMaturityDate = "14/10/2010",
      genCondition1 = "lala",
      genFactor = 4)

    val rdmInstrument = EquityIndexSwap20Instrument.mapToRdm(raw20)

    assert(rdmInstrument.isInstanceOf[RdmEquityIndexSwap])
  }

  test("testMapToBarra") {

  }

  test("testGetAssetId") {
    assert(EquityIndexSwap20Instrument.getAssetId() === "1420")
  }

}
