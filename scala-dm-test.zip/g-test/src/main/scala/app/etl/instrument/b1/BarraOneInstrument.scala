package app.etl.instrument.b1

import app.etl.instrument.RdmInstrument
import javax.xml.crypto.dsig.XMLObject

trait BarraOneInstrument {
  def mapToBarra(rdmInstrument: RdmInstrument): XMLObject
}
