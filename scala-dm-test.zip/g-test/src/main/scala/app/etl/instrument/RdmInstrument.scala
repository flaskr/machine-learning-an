package app.etl.instrument

trait RdmInstrument extends Instrument {

}
