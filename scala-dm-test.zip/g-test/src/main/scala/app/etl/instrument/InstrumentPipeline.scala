package app.etl.instrument

import app.etl.instrument.b1.EquityIndexSwap20Instrument
import app.etl.instrument.b1.EquityIndexSwap20Instrument.RawEquityIndexSwap


object InstrumentPipeline extends App {
  val raw20: RawInstrument = RawEquityIndexSwap(
    contractId = "13",
    negoId = "413",
    ethMaturityDate = "14/10/2010",
    genCondition1 = "lala",
    genFactor = 4)

  val rdm20 = EquityIndexSwap20Instrument.mapToRdm(raw20)
  println(rdm20.getAssetId())
  println(rdm20)
}
