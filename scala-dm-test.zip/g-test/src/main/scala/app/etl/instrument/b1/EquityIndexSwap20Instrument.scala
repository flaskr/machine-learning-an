package app.etl.instrument.b1

import app.etl.instrument.{InstrumentEntity, RawInstrument, RdmInstrument}
import javax.xml.crypto.dsig.XMLObject

object EquityIndexSwap20Instrument extends InstrumentEntity with BarraOneInstrument {
  private val assetId: String = "1420"

  case class RawEquityIndexSwap(contractId: String,
                                negoId: String,
                                ethMaturityDate: String,
                                genCondition1: String,
                                genFactor: Integer) extends RawInstrument {
    override def getAssetId(): String = assetId
  }

  case class RdmEquityIndexSwap(contractId: String,
                                negoId: String,
                                maturityDate: String,
                                theCondition: String,
                                numberFactor: Integer) extends RdmInstrument {
    override def getAssetId(): String = assetId
  }

  override def getAssetId(): String = assetId

  override def mapToRdm(rawInstrument: RawInstrument): RdmInstrument = {
    val raw: RawEquityIndexSwap = rawInstrument.asInstanceOf[RawEquityIndexSwap]
    RdmEquityIndexSwap(contractId = raw.contractId,
                        negoId = raw.negoId,
                        maturityDate = raw.ethMaturityDate,
                        theCondition = raw.genCondition1,
                        numberFactor = raw.genFactor + 2 )
  }

  override def mapToBarra(rdmInstrument: RdmInstrument): XMLObject = {
    XMLObject
  }
}
