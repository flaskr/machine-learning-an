package app.etl.instrument

trait InstrumentEntity extends Instrument {
  def mapToRdm(rawInstrument: RawInstrument) : RdmInstrument
}
