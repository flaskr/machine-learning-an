package app.etl.instrument

trait RawInstrument extends Instrument {

}
