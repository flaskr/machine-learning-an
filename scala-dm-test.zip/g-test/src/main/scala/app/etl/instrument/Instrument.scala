package app.etl.instrument

trait Instrument {
  def getAssetId(): String
}
